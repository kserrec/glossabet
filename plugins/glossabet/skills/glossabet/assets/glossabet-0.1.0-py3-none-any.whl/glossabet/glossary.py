"""The persistent glossary: glossabet-out/glossary.json.

Deliberately minimal schema (PLAN.md: the ontology grows only when a consumer
needs a field). The status lifecycle exists from day one because drift
detection is defined against it. Only a human-approved term is ever
"canonical" — the engine validates and persists; it never promotes. An
optional path-prefix scope lets a term have different owners in disjoint
subsystems; an omitted scope retains the original repository-wide meaning.
"""

from __future__ import annotations

import hashlib
import json
import sys
import unicodedata
from pathlib import Path

from glossabet.artifacts import (
    READ_ABSENT,
    READ_OVERSIZED,
    ArtifactError,
    MAX_JSON_BYTES,
    OUT_DIR,
    confined_artifact_path,
    parse_bounded_json,
    read_bounded_json,
    repo_root,
    write_artifact,
)
from glossabet.display import (
    contains_terminal_control,
    escape_terminal_text,
    print_error,
)

GLOSSARY_SCHEMA_VERSION = 1
GLOSSARY_FILE = "glossary.json"

STATUSES = frozenset(
    {"canonical", "proposed", "alias", "discouraged", "deprecated", "unknown"}
)
# Bindings target stable identities only (PLAN principle 7): never graph
# community numbers or node ids, which shift across rebuilds.
BINDING_KINDS = frozenset({"symbol", "file", "module"})
_REQUIRED_CONCEPT_KEYS = ("id", "term", "definition", "status")
SCOPE_PATHS_KEY = "path_prefixes"

_TOP_LEVEL_KEYS = frozenset({"schema_version", "concepts"})
_CONCEPT_KEYS = frozenset(
    {
        "id", "term", "definition", "status", "scope", "aliases",
        "bindings", "notes",
    }
)
_ALIAS_KEYS = frozenset({"term", "status", "note"})
_BINDING_KEYS = frozenset({"ref"})

# JSON bytes are bounded before parsing, but validation also needs semantic
# limits: a compact hostile document can otherwise create quadratic owner
# comparisons or an enormous diagnostic. These are accepted-input ceilings,
# not targets for a useful human glossary.
MAX_GLOSSARY_CONCEPTS = 10_000
MAX_GLOSSARY_ALIASES = 50_000
MAX_GLOSSARY_BINDINGS = 50_000
MAX_GLOSSARY_SCOPE_PREFIXES = 50_000
MAX_GLOSSARY_SCOPE_CHARACTERS = 1_000_000
MAX_GLOSSARY_OWNERSHIP_SCOPE_CHARACTERS = 5_000_000
MAX_GLOSSARY_IDENTITY_CHARS = 1_024
MAX_GLOSSARY_PROSE_CHARS = 16_384
MAX_VALIDATION_ERRORS = 100


class GlossaryError(ValueError):
    """The glossary file exists but is not usable as written."""


def glossary_sha256(glossary: dict) -> str:
    """Return the semantic digest used to bind every vocabulary projection."""
    canonical = json.dumps(
        glossary,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _fold_vocabulary(term: str) -> str:
    return unicodedata.normalize("NFKC", term.strip()).casefold()


def _bounded_repr(value: object, limit: int = 160) -> str:
    if isinstance(value, str):
        if len(value) <= limit:
            return repr(value)
        return repr(value[:limit]) + "…"
    if isinstance(value, bytes):
        if len(value) <= limit:
            return repr(value)
        return repr(value[:limit]) + "…"
    if isinstance(value, (list, tuple, set, frozenset, dict)):
        return f"<{type(value).__name__} with {len(value)} item(s)>"
    if value is None or isinstance(value, (bool, int, float)):
        return repr(value)
    return f"<{type(value).__name__}>"


class _ValidationErrors:
    """Count every error while retaining a fixed-size useful prefix."""

    def __init__(self) -> None:
        self.messages: list[str] = []
        self.total = 0

    def add(self, message: str) -> None:
        self.total += 1
        if len(self.messages) < MAX_VALIDATION_ERRORS - 1:
            self.messages.append(message)

    def finish(self) -> list[str]:
        omitted = self.total - len(self.messages)
        if omitted:
            self.messages.append(
                f"... {omitted} additional validation error(s) omitted"
            )
        return self.messages


def _unknown_fields(
    value: dict, allowed: frozenset[str], where: str,
    errors: _ValidationErrors,
) -> None:
    unknown_count = 0
    samples: list[object] = []
    for key in value:
        if isinstance(key, str) and key in allowed:
            continue
        unknown_count += 1
        if len(samples) < 10:
            samples.append(key)
    if unknown_count:
        rendered = ", ".join(
            sorted(_bounded_repr(key) for key in samples)
        )
        if unknown_count > len(samples):
            rendered += f", ... and {unknown_count - len(samples)} more"
        errors.add(f"{where} has unknown field(s): {rendered}")


def _string_field(
    value: object,
    where: str,
    errors: _ValidationErrors,
    *,
    required: bool,
    prose: bool = False,
) -> str | None:
    if not isinstance(value, str) or (required and not value.strip()):
        qualifier = "non-empty " if required else ""
        errors.add(f"{where} must be a {qualifier}string")
        return None
    limit = MAX_GLOSSARY_PROSE_CHARS if prose else MAX_GLOSSARY_IDENTITY_CHARS
    if len(value) > limit:
        errors.add(f"{where} exceeds {limit} characters")
        return None
    if contains_terminal_control(value, allow_layout=prose):
        errors.add(
            f"{where} contains a terminal control or bidirectional-format character"
        )
        return None
    return value


def _scope_from_raw(
    raw: object, where: str, errors: _ValidationErrors,
) -> tuple[tuple[str, ...] | None, bool]:
    """Validate and normalize one concept scope; ``None`` means repository-wide."""
    if raw is None:
        errors.add(f"{where}.scope must be an object; omit it for repository-wide")
        return None, False
    if not isinstance(raw, dict):
        errors.add(f"{where}.scope must be an object")
        return None, False
    _unknown_fields(raw, frozenset({SCOPE_PATHS_KEY}), f"{where}.scope", errors)
    prefixes = raw.get(SCOPE_PATHS_KEY)
    if not isinstance(prefixes, list) or not prefixes:
        errors.add(f"{where}.scope.{SCOPE_PATHS_KEY} must be a non-empty list")
        return None, False
    valid: list[str] = []
    for index, prefix in enumerate(prefixes):
        path_where = f"{where}.scope.{SCOPE_PATHS_KEY}[{index}]"
        prefix = _string_field(prefix, path_where, errors, required=True)
        if prefix is None:
            continue
        parts = prefix.split("/")
        if (
            prefix != prefix.strip()
            or prefix.startswith("/")
            or "\\" in prefix
            or "\0" in prefix
            or any(part in ("", ".", "..") for part in parts)
            or any(char in prefix for char in "*?[]")
        ):
            errors.add(
                f"{path_where} must be a literal repository-relative path prefix"
            )
            continue
        valid.append(prefix)
    if len(set(valid)) != len(valid):
        errors.add(f"{where}.scope.{SCOPE_PATHS_KEY} contains duplicate paths")
    unique = set(valid)
    overlapping = False
    ancestry: list[str] = []
    for prefix in sorted(unique):
        while ancestry and not prefix.startswith(ancestry[-1] + "/"):
            ancestry.pop()
        if ancestry:
            overlapping = True
            break
        ancestry.append(prefix)
    if overlapping:
        errors.add(
            f"{where}.scope.{SCOPE_PATHS_KEY} contains overlapping paths"
        )
    usable = bool(valid) and len(unique) == len(valid) and not overlapping
    return (tuple(sorted(unique)) if usable else None), usable


class _ScopeNode:
    __slots__ = ("children", "owner_here", "subtree_owner")

    def __init__(self) -> None:
        self.children: dict[str, _ScopeNode] = {}
        self.owner_here: tuple[int, str, str] | None = None
        self.subtree_owner: tuple[int, str, str] | None = None


class _ScopeOwnerIndex:
    """Find one overlapping vocabulary owner in path-prefix time.

    A repository-wide owner overlaps every path. Scoped owners live in a trie:
    overlap is either an owner on an ancestor node or any owner in the queried
    node's subtree. Validation therefore avoids comparing every concept with
    every earlier concept that uses the same word.
    """

    def __init__(self) -> None:
        self.global_owner: tuple[int, str, str] | None = None
        self.root = _ScopeNode()

    def conflict(
        self, scope: tuple[str, ...] | None
    ) -> tuple[int, str, str] | None:
        if self.global_owner is not None:
            return self.global_owner
        if scope is None:
            return self.root.subtree_owner
        for prefix in scope:
            node = self.root
            for part in prefix.split("/"):
                if node.owner_here is not None:
                    return node.owner_here
                child = node.children.get(part)
                if child is None:
                    break
                node = child
            else:
                if node.owner_here is not None:
                    return node.owner_here
                if node.subtree_owner is not None:
                    return node.subtree_owner
        return None

    def add(
        self, scope: tuple[str, ...] | None, owner: tuple[int, str, str]
    ) -> None:
        if scope is None:
            if self.global_owner is None:
                self.global_owner = owner
            return
        for prefix in scope:
            node = self.root
            if node.subtree_owner is None:
                node.subtree_owner = owner
            for part in prefix.split("/"):
                node = node.children.setdefault(part, _ScopeNode())
                if node.subtree_owner is None:
                    node.subtree_owner = owner
            if node.owner_here is None:
                node.owner_here = owner


def _within_aggregate_limits(
    concepts: list[object], errors: _ValidationErrors
) -> bool:
    starting_errors = errors.total
    if len(concepts) > MAX_GLOSSARY_CONCEPTS:
        errors.add(
            f"concepts exceeds the {MAX_GLOSSARY_CONCEPTS}-concept limit"
        )
        return False
    aliases = bindings = scope_prefixes = scope_characters = 0
    ownership_scope_characters = 0
    for concept in concepts:
        if not isinstance(concept, dict):
            continue
        raw_aliases = concept.get("aliases")
        raw_bindings = concept.get("bindings")
        raw_scope = concept.get("scope")
        if isinstance(raw_aliases, list):
            aliases += len(raw_aliases)
        if isinstance(raw_bindings, list):
            bindings += len(raw_bindings)
        if isinstance(raw_scope, dict):
            raw_prefixes = raw_scope.get(SCOPE_PATHS_KEY)
            if isinstance(raw_prefixes, list):
                scope_prefixes += len(raw_prefixes)
                concept_scope_characters = sum(
                    len(prefix) for prefix in raw_prefixes
                    if isinstance(prefix, str)
                )
                scope_characters += concept_scope_characters
                vocabulary_entries = 1 + (
                    len(raw_aliases) if isinstance(raw_aliases, list) else 0
                )
                ownership_scope_characters += (
                    vocabulary_entries * max(1, concept_scope_characters)
                )
    if aliases > MAX_GLOSSARY_ALIASES:
        errors.add(f"aliases exceeds the {MAX_GLOSSARY_ALIASES}-entry limit")
    if bindings > MAX_GLOSSARY_BINDINGS:
        errors.add(f"bindings exceeds the {MAX_GLOSSARY_BINDINGS}-entry limit")
    if scope_prefixes > MAX_GLOSSARY_SCOPE_PREFIXES:
        errors.add(
            "scope path prefixes exceeds the "
            f"{MAX_GLOSSARY_SCOPE_PREFIXES}-entry limit"
        )
    if scope_characters > MAX_GLOSSARY_SCOPE_CHARACTERS:
        errors.add(
            "scope path prefixes exceed the "
            f"{MAX_GLOSSARY_SCOPE_CHARACTERS}-character aggregate limit"
        )
    if ownership_scope_characters > MAX_GLOSSARY_OWNERSHIP_SCOPE_CHARACTERS:
        errors.add(
            "vocabulary ownership scope work exceeds the "
            f"{MAX_GLOSSARY_OWNERSHIP_SCOPE_CHARACTERS}-character limit"
        )
    return errors.total == starting_errors


def concept_scope(concept: dict) -> tuple[str, ...] | None:
    """Return a validated concept's normalized prefixes, or None for global."""
    raw = concept.get("scope")
    if raw is None:
        return None
    prefixes = raw.get(SCOPE_PATHS_KEY, []) if isinstance(raw, dict) else []
    return tuple(sorted(prefixes)) if prefixes else None


def path_in_scope(path: str, scope: tuple[str, ...] | None) -> bool:
    """Whether a repository-relative file/module path falls inside scope."""
    return scope is None or any(
        path == prefix or path.startswith(prefix + "/") for prefix in scope
    )


def scopes_overlap(
    left: tuple[str, ...] | None, right: tuple[str, ...] | None
) -> bool:
    """Repository-wide overlaps everything; path scopes overlap by ancestry."""
    if left is None or right is None:
        return True
    return any(
        a == b or a.startswith(b + "/") or b.startswith(a + "/")
        for a in left
        for b in right
    )


def scope_evidence(scope: tuple[str, ...] | None) -> dict:
    """Stable serialized scope metadata used by drift and validation reports."""
    if scope is None:
        return {"kind": "repository"}
    return {"kind": "path-prefixes", SCOPE_PATHS_KEY: list(scope)}


def validate_glossary(glossary: object) -> list[str]:
    errors = _ValidationErrors()
    if not isinstance(glossary, dict):
        return ["top level must be an object"]
    _unknown_fields(glossary, _TOP_LEVEL_KEYS, "top level", errors)
    if glossary.get("schema_version") != GLOSSARY_SCHEMA_VERSION:
        errors.add(
            f"schema_version must be {GLOSSARY_SCHEMA_VERSION}, "
            f"got {_bounded_repr(glossary.get('schema_version'))}"
        )
    concepts = glossary.get("concepts")
    if not isinstance(concepts, list):
        errors.add("concepts must be a list")
        return errors.finish()
    if not _within_aggregate_limits(concepts, errors):
        return errors.finish()
    seen_ids: set[str] = set()
    vocabulary_owners: dict[str, _ScopeOwnerIndex] = {}

    def claim_vocabulary(
        folded: str, owner: tuple[int, str, str],
        scope: tuple[str, ...] | None,
    ) -> tuple[int, str, str] | None:
        index = vocabulary_owners.setdefault(folded, _ScopeOwnerIndex())
        previous = index.conflict(scope)
        index.add(scope, owner)
        return previous

    for i, concept in enumerate(concepts):
        where = f"concepts[{i}]"
        if not isinstance(concept, dict):
            errors.add(f"{where} must be an object")
            continue
        _unknown_fields(concept, _CONCEPT_KEYS, where, errors)
        strings: dict[str, str | None] = {}
        for key in _REQUIRED_CONCEPT_KEYS:
            strings[key] = _string_field(
                concept.get(key), f"{where} field {key!r}", errors,
                required=True, prose=key == "definition",
            )
        for key in ("notes",):
            if key in concept:
                _string_field(
                    concept[key], f"{where}.{key}", errors,
                    required=False, prose=True,
                )
        status = strings["status"]
        if status is not None and status not in STATUSES:
            errors.add(
                f"{where} status {status!r} not one of {sorted(STATUSES)}"
            )
        scope, scope_valid = (
            _scope_from_raw(concept["scope"], where, errors)
            if "scope" in concept else (None, True)
        )
        cid = strings["id"]
        if cid is not None:
            if cid in seen_ids:
                errors.add(f"{where} duplicate id {cid!r}")
            seen_ids.add(cid)
        term = strings["term"]
        owner_id = cid if cid is not None else "<invalid>"
        if term is not None and scope_valid:
            folded = _fold_vocabulary(term)
            previous = claim_vocabulary(
                folded, (i, owner_id, "term"), scope
            )
            if previous is not None:
                if previous[2] == "term":
                    errors.add(
                        f"{where} duplicate term {term!r} in overlapping "
                        f"scopes ({previous[1]!r} and {owner_id!r})"
                    )
                else:
                    errors.add(
                        f"{where} term {term!r} maps to multiple concepts "
                        f"in overlapping scopes ({previous[1]!r} and "
                        f"{owner_id!r})"
                    )
        aliases = concept.get("aliases", [])
        if not isinstance(aliases, list):
            errors.add(f"{where}.aliases must be a list")
            aliases = []
        for j, alias in enumerate(aliases):
            aw = f"{where}.aliases[{j}]"
            if not isinstance(alias, dict):
                errors.add(f"{aw} must be an object")
                continue
            _unknown_fields(alias, _ALIAS_KEYS, aw, errors)
            alias_term = _string_field(
                alias.get("term"), f"{aw}.term", errors, required=True
            )
            alias_status = _string_field(
                alias.get("status"), f"{aw}.status", errors, required=True
            )
            if "note" in alias:
                _string_field(
                    alias["note"], f"{aw}.note", errors,
                    required=False, prose=True,
                )
            if alias_status is not None and alias_status not in STATUSES:
                errors.add(
                    f"{aw} status {alias_status!r} not one of "
                    f"{sorted(STATUSES)}"
                )
            if alias_term is None or not scope_valid:
                continue
            folded_alias = _fold_vocabulary(alias_term)
            previous = claim_vocabulary(
                folded_alias, (i, owner_id, "alias"), scope
            )
            if previous is not None:
                if previous[0] != i:
                    errors.add(
                        f"{aw} alias term {alias_term!r} maps to multiple "
                        f"concepts in overlapping scopes "
                        f"({previous[1]!r} and {owner_id!r})"
                    )
                else:
                    errors.add(
                        f"{aw} duplicate vocabulary term {alias_term!r} "
                        f"within concept {owner_id!r}"
                    )
        bindings = concept.get("bindings", [])
        if not isinstance(bindings, list):
            errors.add(f"{where}.bindings must be a list")
            bindings = []
        for j, binding in enumerate(bindings):
            bw = f"{where}.bindings[{j}]"
            if not isinstance(binding, dict):
                errors.add(f"{bw} must be an object")
                continue
            _unknown_fields(binding, _BINDING_KEYS, bw, errors)
            ref = _string_field(
                binding.get("ref"), f"{bw}.ref", errors, required=True
            )
            if ref is None:
                continue
            if ":" not in ref:
                errors.add(f"{bw} needs a 'ref' like 'symbol:Name'")
                continue
            kind, _, target = ref.partition(":")
            if not target.strip():
                errors.add(f"{bw} needs a 'ref' like 'symbol:Name'")
                continue
            if kind not in BINDING_KINDS:
                errors.add(
                    f"{bw} unsupported ref kind {kind!r} — bindings target "
                    f"stable identities only ({sorted(BINDING_KINDS)}); "
                    "community/node ids are not stable across graph rebuilds"
                )
    return errors.finish()


def load_glossary(root: Path) -> dict | None:
    """Return the validated glossary, None if absent, GlossaryError if bad."""
    try:
        path = confined_artifact_path(root, f"{OUT_DIR}/{GLOSSARY_FILE}")
    except ArtifactError as exc:
        raise GlossaryError(str(exc)) from exc
    read = read_bounded_json(path)
    if read.status == READ_ABSENT:
        return None
    if read.status == READ_OVERSIZED:
        raise GlossaryError(
            f"{path}: larger than {read.cap} bytes — refusing to load"
        )
    if not read.ok:
        raise GlossaryError(f"{path}: unreadable JSON ({read.error})")
    glossary = read.value
    errors = validate_glossary(glossary)
    if errors:
        raise GlossaryError(f"{path}: " + "; ".join(errors))
    return glossary


def save_glossary(root: Path, glossary: dict) -> Path:
    errors = validate_glossary(glossary)
    if errors:
        raise GlossaryError("refusing to save invalid glossary: "
                            + "; ".join(errors))
    glossary = dict(glossary)
    concepts = []
    for original in glossary["concepts"]:
        concept = dict(original)
        scope = concept.get("scope")
        if isinstance(scope, dict):
            concept["scope"] = {
                SCOPE_PATHS_KEY: sorted(scope[SCOPE_PATHS_KEY])
            }
        concepts.append(concept)
    glossary["concepts"] = sorted(concepts, key=lambda c: c["id"])
    return write_artifact(root, GLOSSARY_FILE, glossary)


def require_glossary(root: Path, missing: str) -> dict | None:
    """Loaded glossary, or None after reporting why there is nothing usable.

    `missing` is the leading clause for the no-glossary-yet message, e.g.
    "no glossary to validate".
    """
    try:
        glossary = load_glossary(root)
    except GlossaryError as exc:
        print_error(exc)
        return None
    if glossary is None:
        safe_missing = escape_terminal_text(missing)
        print(
            f"glossabet: {safe_missing} — run /glossabet and settle terms "
            f"first ({OUT_DIR}/{GLOSSARY_FILE})",
            file=sys.stderr,
        )
        return None
    return glossary


def show_command(path_arg: str) -> int:
    root = repo_root(path_arg)
    if root is None:
        return 1
    try:
        glossary = load_glossary(root)
    except GlossaryError as exc:
        print_error(exc)
        return 1
    if glossary is None:
        print(
            "no glossary yet — run /glossabet and settle terms to create "
            f"{OUT_DIR}/{GLOSSARY_FILE}"
        )
        return 0

    concepts = sorted(glossary["concepts"], key=lambda c: c["id"])
    by_status: dict[str, list[dict]] = {}
    for concept in concepts:
        by_status.setdefault(concept["status"], []).append(concept)
    counts = ", ".join(
        f"{len(v)} {k}" for k, v in sorted(by_status.items())
    )
    print(f"glossary: {counts}")
    for status in ("canonical", "proposed", "deprecated", "discouraged",
                   "alias", "unknown"):
        group = by_status.get(status)
        if not group:
            continue
        print(f"\n== {status} ==")
        for concept in group:
            term = escape_terminal_text(concept["term"])
            definition = escape_terminal_text(concept["definition"])
            print(f"{term} — {definition}")
            scope = concept_scope(concept)
            if scope is not None:
                print(
                    "    scope: "
                    + ", ".join(escape_terminal_text(path) for path in scope)
                )
            for alias in concept.get("aliases", []):
                alias_term = escape_terminal_text(alias["term"])
                alias_status = escape_terminal_text(alias["status"])
                note = (
                    f" ({escape_terminal_text(alias['note'])})"
                    if alias.get("note") else ""
                )
                print(f"    alias: {alias_term} [{alias_status}]{note}")
            if concept.get("notes"):
                print(f"    note: {escape_terminal_text(concept['notes'])}")
    return 0


def save_command(path_arg: str) -> int:
    """Validate JSON from stdin and persist it through the safe writer."""
    root = repo_root(path_arg)
    if root is None:
        return 1
    if sys.stdin.isatty():
        print(
            "glossabet: save requires one glossary JSON document on "
            "standard input",
            file=sys.stderr,
        )
        return 1

    stream = getattr(sys.stdin, "buffer", sys.stdin)
    try:
        raw = stream.read(MAX_JSON_BYTES + 1)
    except (OSError, UnicodeError) as exc:
        print(
            "glossabet: cannot read glossary JSON from standard input: "
            + escape_terminal_text(str(exc)),
            file=sys.stderr,
        )
        return 1
    parsed = parse_bounded_json(raw, MAX_JSON_BYTES)
    if parsed.status == READ_OVERSIZED:
        print(
            "glossabet: glossary JSON on standard input is larger than "
            f"{MAX_JSON_BYTES} bytes",
            file=sys.stderr,
        )
        return 1
    if not parsed.ok:
        print(
            "glossabet: glossary JSON on standard input is unreadable ("
            + escape_terminal_text(parsed.error) + ")",
            file=sys.stderr,
        )
        return 1
    try:
        path = save_glossary(root, parsed.value)
    except (GlossaryError, ArtifactError) as exc:
        print_error(exc)
        return 1
    print("saved glossary: " + escape_terminal_text(str(path)))
    return 0
